module.exports = {
  database:'mongodb://hari_pro:pro_hari123@ds149672.mlab.com:49672/login',
 secret:'god'
}
